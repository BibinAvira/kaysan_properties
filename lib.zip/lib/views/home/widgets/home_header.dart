import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/routes/route_names.dart';
import '../../../core/theme/app_colors.dart';
import '../../../widgets/glass/liquid_glass.dart';

/// Which property-status bucket the Home "Top Property" list is filtered
/// to. `null` means "All". Kept local to Home rather than wired into the
/// full [ProjectFilter]/Listings filter stack, since this is a lightweight
/// at-a-glance toggle rather than the full filter sheet.
class HomeStatusFilterController extends Notifier<int?> {
  @override
  int? build() => null;

  void set(int? value) => state = value;
}

final NotifierProvider<HomeStatusFilterController, int?> homeStatusFilterProvider =
    NotifierProvider<HomeStatusFilterController, int?>(HomeStatusFilterController.new);

/// "Hello 👋" greeting + location row + notification bell, replacing the
/// plain app bar title. There's no auth/user model in this app yet, so
/// the greeting stays generic rather than inventing a fake name.
class HomeGreetingHeader extends StatelessWidget {
  const HomeGreetingHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('Hello 👋', style: theme.textTheme.bodyMedium),
                const SizedBox(height: 2),
                Row(
                  children: <Widget>[
                    const Icon(Icons.location_on, size: 16, color: AppColors.gold),
                    const SizedBox(width: 2),
                    Text('Dubai, UAE', style: theme.textTheme.titleMedium),
                    const Icon(Icons.keyboard_arrow_down, size: 18),
                  ],
                ),
              ],
            ),
          ),
          LiquidGlassCircle(
            icon: Icons.notifications_none_rounded,
            iconColor: AppColors.textPrimaryLight,
            onTap: () {},
          ),
        ],
      ),
    );
  }
}

/// The bold "Explore Modern Living Spaces Near You"-style headline.
class HomeHeadline extends StatelessWidget {
  const HomeHeadline({super.key});

  @override
  Widget build(BuildContext context) {
    final TextStyle? style = Theme.of(context).textTheme.displayMedium;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      child: Text.rich(
        TextSpan(
          style: style?.copyWith(fontWeight: FontWeight.w500),
          children: <InlineSpan>[
            const TextSpan(text: 'Explore '),
            TextSpan(
              text: 'Off-Plan Properties',
              style: style?.copyWith(fontWeight: FontWeight.w700),
            ),
            const TextSpan(text: ' in Dubai'),
          ],
        ),
      ),
    );
  }
}

/// Rounded search field + filter button, matching the Figma search row.
class HomeSearchBar extends StatelessWidget {
  const HomeSearchBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: <Widget>[
          Expanded(
            child: GestureDetector(
              onTap: () => context.push(RouteNames.search),
              child: LiquidGlass(
                borderRadius: 26,
                blur: 26,
                tintOpacity: 0.55,
                borderOpacity: 0.5,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: <Widget>[
                    const Icon(Icons.search, color: AppColors.textSecondaryLight),
                    const SizedBox(width: 10),
                    Text('Search',
                        style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          LiquidGlassCircle(
            icon: Icons.tune_rounded,
            iconColor: AppColors.textPrimaryLight,
            tintOpacity: 0.55,
            onTap: () => context.push(RouteNames.search),
          ),
        ],
      ),
    );
  }
}

/// "Apartment / Ready / Off-Plan" style pill row. Maps onto the real
/// [ProjectModel.propertyStatusCode] the API already exposes (1 = Ready,
/// 2 = Off-Plan) rather than inventing categories the data can't back up.
class HomeCategoryChips extends ConsumerWidget {
  const HomeCategoryChips({super.key});

  static const List<(String, int?)> _options = <(String, int?)>[
    ('All Projects', null),
    ('Ready', 1),
    ('Off-Plan', 2),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final int? selected = ref.watch(homeStatusFilterProvider);
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _options.length,
        separatorBuilder: (BuildContext context, int index) => const SizedBox(width: 10),
        itemBuilder: (BuildContext context, int index) {
          final (String label, int? value) = _options[index];
          final bool active = selected == value;
          return GestureDetector(
            onTap: () => ref.read(homeStatusFilterProvider.notifier).set(value),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeOutCubic,
              child: active
                  ? Container(
                      key: const ValueKey<bool>(true),
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.primaryNavy,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: Text(
                        label,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    )
                  : LiquidGlass(
                      key: const ValueKey<bool>(false),
                      borderRadius: 22,
                      blur: 24,
                      tintOpacity: 0.5,
                      borderOpacity: 0.45,
                      shadow: false,
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Center(
                        child: Text(
                          label,
                          style: const TextStyle(
                            color: AppColors.textSecondaryLight,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ),
            ),
          );
        },
      ),
    );
  }
}

